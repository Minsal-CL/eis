# Inicio - Guía de Estandares de Información de Salud v0.1.1

* [**Table of Contents**](toc.md)
* **Inicio**

## Inicio

| | |
| :--- | :--- |
| *Official URL*:https://interoperabilidad.minsal.cl/fhir/ig/eis/ImplementationGuide/hl7.fhir.cl.minsal.eis | *Version*:0.1.1 |
| Draft as of 2024-03 | *Computable Name*:EstandaresdeInformaciondeSalud |

### Alcance

"Estandares de informatica en Salud" busca ser la base terminológica de todas las guías de implementaciones en Chile. Siendo la versión FHIR de la "Norma 820" en su última versión 3.0 del 12-01-2023.

### Dependencias, versiones y propiedad intelectual

#### Dependencias



#### Analisis de versiones cruzadas

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (hl7.fhir.cl.minsal.eis.r4)](package.r4.tgz) and [R4B (hl7.fhir.cl.minsal.eis.r4b)](package.r4b.tgz) are available.

#### Perfiles globales

*There are no Global profiles defined*

#### Declaracion de propiedad intelectual

No use of external IP

