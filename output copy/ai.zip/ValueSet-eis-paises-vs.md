# Códigos de Países - Guía de Estandares de Información de Salud v0.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Códigos de Países**

## ValueSet: Códigos de Países 

| | |
| :--- | :--- |
| *Official URL*:https://interoperabilidad.minsal.cl/fhir/ig/eis/ValueSet/eis-paises-vs | *Version*:0.1.1 |
| Active as of 2022-01-18 | *Computable Name*:PaisesVS |
| **Copyright/Legal**: All content on ISO Online is copyright protected. The copyright is owned by ISO. Any use of the content, including copying of it in whole or in part, for example to another Internet site, is prohibited and would require written permission from ISO. | |

 
Codigos definidos para la identificación de países segun norma ISO3166-N 

 **References** 

* [Códigos para Países](StructureDefinition-eis-paises.md)
* [Códigos para Países](StructureDefinition-eis-paises.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "eis-paises-vs",
  "language" : "es",
  "url" : "https://interoperabilidad.minsal.cl/fhir/ig/eis/ValueSet/eis-paises-vs",
  "version" : "0.1.1",
  "name" : "PaisesVS",
  "title" : "Códigos de Países",
  "status" : "active",
  "experimental" : false,
  "date" : "2022-01-18T00:00:00-03:00",
  "publisher" : "Unidad de Interoperabilidad - MINSAL",
  "contact" : [{
    "name" : "Unidad de Interoperabilidad - MINSAL",
    "telecom" : [{
      "system" : "url",
      "value" : "https://interoperabilidad.minsal.cl"
    }]
  }],
  "description" : "Codigos definidos para la identificación de países segun norma ISO3166-N",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "CL",
      "display" : "Chile"
    }]
  }],
  "copyright" : "All content on ISO Online is copyright protected. The copyright is owned by ISO. Any use of the content, including copying of it in whole or in part, for example to another Internet site, is prohibited and would require written permission from ISO.",
  "compose" : {
    "include" : [{
      "system" : "urn:iso:std:iso:3166",
      "concept" : [{
        "code" : "004",
        "display" : "Afghanistan"
      },
      {
        "code" : "008",
        "display" : "Albania"
      },
      {
        "code" : "010",
        "display" : "Antarctica"
      },
      {
        "code" : "012",
        "display" : "Algeria"
      },
      {
        "code" : "016",
        "display" : "American Samoa"
      },
      {
        "code" : "020",
        "display" : "Andorra"
      },
      {
        "code" : "024",
        "display" : "Angola"
      },
      {
        "code" : "028",
        "display" : "Antigua and Barbuda"
      },
      {
        "code" : "031",
        "display" : "Azerbaijan"
      },
      {
        "code" : "032",
        "display" : "Argentina"
      },
      {
        "code" : "036",
        "display" : "Australia"
      },
      {
        "code" : "040",
        "display" : "Austria"
      },
      {
        "code" : "044",
        "display" : "Bahamas"
      },
      {
        "code" : "048",
        "display" : "Bahrain"
      },
      {
        "code" : "050",
        "display" : "Bangladesh"
      },
      {
        "code" : "051",
        "display" : "Armenia"
      },
      {
        "code" : "052",
        "display" : "Barbados"
      },
      {
        "code" : "056",
        "display" : "Belgium"
      },
      {
        "code" : "060",
        "display" : "Bermuda"
      },
      {
        "code" : "064",
        "display" : "Bhutan"
      },
      {
        "code" : "068",
        "display" : "Bolivia, Plurinational State of"
      },
      {
        "code" : "070",
        "display" : "Bosnia and Herzegovina"
      },
      {
        "code" : "072",
        "display" : "Botswana"
      },
      {
        "code" : "074",
        "display" : "Bouvet Island"
      },
      {
        "code" : "076",
        "display" : "Brazil"
      },
      {
        "code" : "084",
        "display" : "Belize"
      },
      {
        "code" : "086",
        "display" : "British Indian Ocean Territory"
      },
      {
        "code" : "090",
        "display" : "Solomon Islands"
      },
      {
        "code" : "092",
        "display" : "Virgin Islands, British"
      },
      {
        "code" : "096",
        "display" : "Brunei Darussalam"
      },
      {
        "code" : "100",
        "display" : "Bulgaria"
      },
      {
        "code" : "104",
        "display" : "Myanmar"
      },
      {
        "code" : "108",
        "display" : "Burundi"
      },
      {
        "code" : "112",
        "display" : "Belarus"
      },
      {
        "code" : "116",
        "display" : "Cambodia"
      },
      {
        "code" : "120",
        "display" : "Cameroon"
      },
      {
        "code" : "124",
        "display" : "Canada"
      },
      {
        "code" : "132",
        "display" : "Cabo Verde"
      },
      {
        "code" : "136",
        "display" : "Cayman Islands"
      },
      {
        "code" : "140",
        "display" : "Central African Republic"
      },
      {
        "code" : "144",
        "display" : "Sri Lanka"
      },
      {
        "code" : "148",
        "display" : "Chad"
      },
      {
        "code" : "152",
        "display" : "Chile"
      },
      {
        "code" : "156",
        "display" : "China"
      },
      {
        "code" : "158",
        "display" : "Taiwan, Province of China"
      },
      {
        "code" : "162",
        "display" : "Christmas Island"
      },
      {
        "code" : "166",
        "display" : "Cocos (Keeling) Islands"
      },
      {
        "code" : "170",
        "display" : "Colombia"
      },
      {
        "code" : "174",
        "display" : "Comoros"
      },
      {
        "code" : "175",
        "display" : "Mayotte"
      },
      {
        "code" : "178",
        "display" : "Congo"
      },
      {
        "code" : "180",
        "display" : "Congo, the Democratic Republic of the"
      },
      {
        "code" : "184",
        "display" : "Cook Islands"
      },
      {
        "code" : "188",
        "display" : "Costa Rica"
      },
      {
        "code" : "191",
        "display" : "Croatia"
      },
      {
        "code" : "192",
        "display" : "Cuba"
      },
      {
        "code" : "196",
        "display" : "Cyprus"
      },
      {
        "code" : "203",
        "display" : "Czechia"
      },
      {
        "code" : "204",
        "display" : "Benin"
      },
      {
        "code" : "208",
        "display" : "Denmark"
      },
      {
        "code" : "212",
        "display" : "Dominica"
      },
      {
        "code" : "214",
        "display" : "Dominican Republic"
      },
      {
        "code" : "218",
        "display" : "Ecuador"
      },
      {
        "code" : "222",
        "display" : "El Salvador"
      },
      {
        "code" : "226",
        "display" : "Equatorial Guinea"
      },
      {
        "code" : "231",
        "display" : "Ethiopia"
      },
      {
        "code" : "232",
        "display" : "Eritrea"
      },
      {
        "code" : "233",
        "display" : "Estonia"
      },
      {
        "code" : "234",
        "display" : "Faroe Islands"
      },
      {
        "code" : "238",
        "display" : "Falkland Islands (Malvinas)"
      },
      {
        "code" : "239",
        "display" : "South Georgia and the South Sandwich Islands"
      },
      {
        "code" : "242",
        "display" : "Fiji"
      },
      {
        "code" : "246",
        "display" : "Finland"
      },
      {
        "code" : "248",
        "display" : "Eland Islands"
      },
      {
        "code" : "250",
        "display" : "France"
      },
      {
        "code" : "254",
        "display" : "French Guiana"
      },
      {
        "code" : "258",
        "display" : "French Polynesia"
      },
      {
        "code" : "260",
        "display" : "French Southern Territories"
      },
      {
        "code" : "262",
        "display" : "Djibouti"
      },
      {
        "code" : "266",
        "display" : "Gabon"
      },
      {
        "code" : "268",
        "display" : "Georgia"
      },
      {
        "code" : "270",
        "display" : "Gambia"
      },
      {
        "code" : "275",
        "display" : "Palestine, State of"
      },
      {
        "code" : "276",
        "display" : "Germany"
      },
      {
        "code" : "288",
        "display" : "Ghana"
      },
      {
        "code" : "292",
        "display" : "Gibraltar"
      },
      {
        "code" : "296",
        "display" : "Kiribati"
      },
      {
        "code" : "300",
        "display" : "Greece"
      },
      {
        "code" : "304",
        "display" : "Greenland"
      },
      {
        "code" : "308",
        "display" : "Grenada"
      },
      {
        "code" : "312",
        "display" : "Guadeloupe"
      },
      {
        "code" : "316",
        "display" : "Guam"
      },
      {
        "code" : "320",
        "display" : "Guatemala"
      },
      {
        "code" : "324",
        "display" : "Guinea"
      },
      {
        "code" : "328",
        "display" : "Guyana"
      },
      {
        "code" : "332",
        "display" : "Haiti"
      },
      {
        "code" : "334",
        "display" : "Heard Island and McDonald Islands"
      },
      {
        "code" : "336",
        "display" : "Holy See"
      },
      {
        "code" : "340",
        "display" : "Honduras"
      },
      {
        "code" : "344",
        "display" : "Hong Kong"
      },
      {
        "code" : "348",
        "display" : "Hungary"
      },
      {
        "code" : "352",
        "display" : "Iceland"
      },
      {
        "code" : "356",
        "display" : "India"
      },
      {
        "code" : "360",
        "display" : "Indonesia"
      },
      {
        "code" : "364",
        "display" : "Iran, Islamic Republic of"
      },
      {
        "code" : "368",
        "display" : "Iraq"
      },
      {
        "code" : "372",
        "display" : "Ireland"
      },
      {
        "code" : "376",
        "display" : "Israel"
      },
      {
        "code" : "380",
        "display" : "Italy"
      },
      {
        "code" : "384",
        "display" : "Ctte d'Ivoire"
      },
      {
        "code" : "388",
        "display" : "Jamaica"
      },
      {
        "code" : "392",
        "display" : "Japan"
      },
      {
        "code" : "398",
        "display" : "Kazakhstan"
      },
      {
        "code" : "400",
        "display" : "Jordan"
      },
      {
        "code" : "404",
        "display" : "Kenya"
      },
      {
        "code" : "408",
        "display" : "Korea, Democratic People's Republic of"
      },
      {
        "code" : "410",
        "display" : "Korea, Republic of"
      },
      {
        "code" : "414",
        "display" : "Kuwait"
      },
      {
        "code" : "417",
        "display" : "Kyrgyzstan"
      },
      {
        "code" : "418",
        "display" : "Lao People's Democratic Republic"
      },
      {
        "code" : "422",
        "display" : "Lebanon"
      },
      {
        "code" : "426",
        "display" : "Lesotho"
      },
      {
        "code" : "428",
        "display" : "Latvia"
      },
      {
        "code" : "430",
        "display" : "Liberia"
      },
      {
        "code" : "434",
        "display" : "Libya"
      },
      {
        "code" : "438",
        "display" : "Liechtenstein"
      },
      {
        "code" : "440",
        "display" : "Lithuania"
      },
      {
        "code" : "442",
        "display" : "Luxembourg"
      },
      {
        "code" : "446",
        "display" : "Macao"
      },
      {
        "code" : "450",
        "display" : "Madagascar"
      },
      {
        "code" : "454",
        "display" : "Malawi"
      },
      {
        "code" : "458",
        "display" : "Malaysia"
      },
      {
        "code" : "462",
        "display" : "Maldives"
      },
      {
        "code" : "466",
        "display" : "Mali"
      },
      {
        "code" : "470",
        "display" : "Malta"
      },
      {
        "code" : "474",
        "display" : "Martinique"
      },
      {
        "code" : "478",
        "display" : "Mauritania"
      },
      {
        "code" : "480",
        "display" : "Mauritius"
      },
      {
        "code" : "484",
        "display" : "Mexico"
      },
      {
        "code" : "492",
        "display" : "Monaco"
      },
      {
        "code" : "496",
        "display" : "Mongolia"
      },
      {
        "code" : "498",
        "display" : "Moldova, Republic of"
      },
      {
        "code" : "499",
        "display" : "Montenegro"
      },
      {
        "code" : "500",
        "display" : "Montserrat"
      },
      {
        "code" : "504",
        "display" : "Morocco"
      },
      {
        "code" : "508",
        "display" : "Mozambique"
      },
      {
        "code" : "512",
        "display" : "Oman"
      },
      {
        "code" : "516",
        "display" : "Namibia"
      },
      {
        "code" : "520",
        "display" : "Nauru"
      },
      {
        "code" : "524",
        "display" : "Nepal"
      },
      {
        "code" : "528",
        "display" : "Netherlands"
      },
      {
        "code" : "531",
        "display" : "Curagao"
      },
      {
        "code" : "533",
        "display" : "Aruba"
      },
      {
        "code" : "534",
        "display" : "Sint Maarten (Dutch part)"
      },
      {
        "code" : "535",
        "display" : "Bonaire, Sint Eustatius and Saba"
      },
      {
        "code" : "540",
        "display" : "New Caledonia"
      },
      {
        "code" : "548",
        "display" : "Vanuatu"
      },
      {
        "code" : "554",
        "display" : "New Zealand"
      },
      {
        "code" : "558",
        "display" : "Nicaragua"
      },
      {
        "code" : "562",
        "display" : "Niger"
      },
      {
        "code" : "566",
        "display" : "Nigeria"
      },
      {
        "code" : "570",
        "display" : "Niue"
      },
      {
        "code" : "574",
        "display" : "Norfolk Island"
      },
      {
        "code" : "578",
        "display" : "Norway"
      },
      {
        "code" : "580",
        "display" : "Northern Mariana Islands"
      },
      {
        "code" : "581",
        "display" : "United States Minor Outlying Islands"
      },
      {
        "code" : "583",
        "display" : "Micronesia, Federated States of"
      },
      {
        "code" : "584",
        "display" : "Marshall Islands"
      },
      {
        "code" : "585",
        "display" : "Palau"
      },
      {
        "code" : "586",
        "display" : "Pakistan"
      },
      {
        "code" : "591",
        "display" : "Panama"
      },
      {
        "code" : "598",
        "display" : "Papua New Guinea"
      },
      {
        "code" : "600",
        "display" : "Paraguay"
      },
      {
        "code" : "604",
        "display" : "Peru"
      },
      {
        "code" : "608",
        "display" : "Philippines"
      },
      {
        "code" : "612",
        "display" : "Pitcairn"
      },
      {
        "code" : "616",
        "display" : "Poland"
      },
      {
        "code" : "620",
        "display" : "Portugal"
      },
      {
        "code" : "624",
        "display" : "Guinea-Bissau"
      },
      {
        "code" : "626",
        "display" : "Timor-Leste"
      },
      {
        "code" : "630",
        "display" : "Puerto Rico"
      },
      {
        "code" : "634",
        "display" : "Qatar"
      },
      {
        "code" : "638",
        "display" : "Riunion"
      },
      {
        "code" : "642",
        "display" : "Romania"
      },
      {
        "code" : "643",
        "display" : "Russian Federation"
      },
      {
        "code" : "646",
        "display" : "Rwanda"
      },
      {
        "code" : "652",
        "display" : "Saint Barthilemy"
      },
      {
        "code" : "654",
        "display" : "Saint Helena, Ascension and Tristan da Cunha"
      },
      {
        "code" : "659",
        "display" : "Saint Kitts and Nevis"
      },
      {
        "code" : "660",
        "display" : "Anguilla"
      },
      {
        "code" : "662",
        "display" : "Saint Lucia"
      },
      {
        "code" : "663",
        "display" : "Saint Martin (French part)"
      },
      {
        "code" : "666",
        "display" : "Saint Pierre and Miquelon"
      },
      {
        "code" : "670",
        "display" : "Saint Vincent and the Grenadines"
      },
      {
        "code" : "674",
        "display" : "San Marino"
      },
      {
        "code" : "678",
        "display" : "Sao Tome and Principe"
      },
      {
        "code" : "682",
        "display" : "Saudi Arabia"
      },
      {
        "code" : "686",
        "display" : "Senegal"
      },
      {
        "code" : "688",
        "display" : "Serbia"
      },
      {
        "code" : "690",
        "display" : "Seychelles"
      },
      {
        "code" : "694",
        "display" : "Sierra Leone"
      },
      {
        "code" : "702",
        "display" : "Singapore"
      },
      {
        "code" : "703",
        "display" : "Slovakia"
      },
      {
        "code" : "704",
        "display" : "Viet Nam"
      },
      {
        "code" : "705",
        "display" : "Slovenia"
      },
      {
        "code" : "706",
        "display" : "Somalia"
      },
      {
        "code" : "710",
        "display" : "South Africa"
      },
      {
        "code" : "716",
        "display" : "Zimbabwe"
      },
      {
        "code" : "724",
        "display" : "Spain"
      },
      {
        "code" : "728",
        "display" : "South Sudan"
      },
      {
        "code" : "729",
        "display" : "Sudan"
      },
      {
        "code" : "732",
        "display" : "Western Sahara"
      },
      {
        "code" : "740",
        "display" : "Suriname"
      },
      {
        "code" : "744",
        "display" : "Svalbard and Jan Mayen"
      },
      {
        "code" : "748",
        "display" : "Swaziland"
      },
      {
        "code" : "752",
        "display" : "Sweden"
      },
      {
        "code" : "756",
        "display" : "Switzerland"
      },
      {
        "code" : "760",
        "display" : "Syrian Arab Republic"
      },
      {
        "code" : "762",
        "display" : "Tajikistan"
      },
      {
        "code" : "764",
        "display" : "Thailand"
      },
      {
        "code" : "768",
        "display" : "Togo"
      },
      {
        "code" : "772",
        "display" : "Tokelau"
      },
      {
        "code" : "776",
        "display" : "Tonga"
      },
      {
        "code" : "780",
        "display" : "Trinidad and Tobago"
      },
      {
        "code" : "784",
        "display" : "United Arab Emirates"
      },
      {
        "code" : "788",
        "display" : "Tunisia"
      },
      {
        "code" : "792",
        "display" : "Turkey"
      },
      {
        "code" : "795",
        "display" : "Turkmenistan"
      },
      {
        "code" : "796",
        "display" : "Turks and Caicos Islands"
      },
      {
        "code" : "798",
        "display" : "Tuvalu"
      },
      {
        "code" : "800",
        "display" : "Uganda"
      },
      {
        "code" : "804",
        "display" : "Ukraine"
      },
      {
        "code" : "807",
        "display" : "Macedonia, the former Yugoslav Republic of"
      },
      {
        "code" : "818",
        "display" : "Egypt"
      },
      {
        "code" : "826",
        "display" : "United Kingdom"
      },
      {
        "code" : "831",
        "display" : "Guernsey"
      },
      {
        "code" : "832",
        "display" : "Jersey"
      },
      {
        "code" : "833",
        "display" : "Isle of Man"
      },
      {
        "code" : "834",
        "display" : "Tanzania, United Republic of"
      },
      {
        "code" : "840",
        "display" : "United States of America"
      },
      {
        "code" : "850",
        "display" : "Virgin Islands, U.S."
      },
      {
        "code" : "854",
        "display" : "Burkina Faso"
      },
      {
        "code" : "858",
        "display" : "Uruguay"
      },
      {
        "code" : "860",
        "display" : "Uzbekistan"
      },
      {
        "code" : "862",
        "display" : "Venezuela, Bolivarian Republic of"
      },
      {
        "code" : "876",
        "display" : "Wallis and Futuna"
      },
      {
        "code" : "882",
        "display" : "Samoa"
      },
      {
        "code" : "887",
        "display" : "Yemen"
      },
      {
        "code" : "894",
        "display" : "Zambia"
      }]
    }]
  }
}

```
